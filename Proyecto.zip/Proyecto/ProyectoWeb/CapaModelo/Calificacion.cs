﻿namespace CapaModelo
{
    public class Calificacion
    {
        public int IdCalificacion { get; set; }
        public Curricula oCurricula { get; set; }
        public Alumno oAlumno { get; set; }
        public float Nota { get; set; }
    }
}
